package com.victorlima.sudoku.service;

import com.victorlima.sudoku.model.Board;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SudokuGameTest {

    @Test
    void shouldParseArgumentsAndKeepFixedCells() {
        String[] args = {
                "0,0;4,true",
                "1,0;7,false"
        };

        Board board = BoardParser.parse(args);

        assertEquals(4, board.getValue(0, 0));
        assertTrue(board.isFixed(0, 0));
        assertEquals(7, board.getValue(0, 1));
        assertFalse(board.isFixed(0, 1));
    }

    @Test
    void shouldRejectInvalidPlacement() {
        Board board = new Board();
        board.setInitialCell(0, 0, 5, true);
        SudokuGame game = new SudokuGame(board);

        boolean result = game.placeNumber(0, 1, 5);

        assertFalse(result);
        assertEquals(0, board.getValue(0, 1));
    }

    @Test
    void shouldSolveSimpleBoard() {
        Board board = new Board();
        int[][] values = {
                {5,3,0,0,7,0,0,0,0},
                {6,0,0,1,9,5,0,0,0},
                {0,9,8,0,0,0,0,6,0},
                {8,0,0,0,6,0,0,0,3},
                {4,0,0,8,0,3,0,0,1},
                {7,0,0,0,2,0,0,0,6},
                {0,6,0,0,0,0,2,8,0},
                {0,0,0,4,1,9,0,0,5},
                {0,0,0,0,8,0,0,7,9}
        };

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (values[row][col] != 0) {
                    board.setInitialCell(row, col, values[row][col], true);
                }
            }
        }

        SudokuGame game = new SudokuGame(board);
        Board solved = game.solveCopy();

        assertTrue(new SudokuValidator().isSolved(solved));
    }
}
