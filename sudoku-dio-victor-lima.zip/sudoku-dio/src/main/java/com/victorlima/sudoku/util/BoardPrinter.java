package com.victorlima.sudoku.util;

import com.victorlima.sudoku.model.Board;

public final class BoardPrinter {

    private BoardPrinter() {
    }

    public static void print(Board board) {
        System.out.println("\n    0 1 2   3 4 5   6 7 8");
        System.out.println("  +-------+-------+-------+");

        for (int row = 0; row < Board.SIZE; row++) {
            System.out.print(row + " | ");
            for (int col = 0; col < Board.SIZE; col++) {
                int value = board.getValue(row, col);
                System.out.print((value == 0 ? "." : value) + " ");
                if ((col + 1) % 3 == 0) {
                    System.out.print("| ");
                }
            }
            System.out.println();
            if ((row + 1) % 3 == 0) {
                System.out.println("  +-------+-------+-------+");
            }
        }
        System.out.println();
    }
}
