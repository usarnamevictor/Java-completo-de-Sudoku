package com.victorlima.sudoku.service;

import com.victorlima.sudoku.model.Board;

import java.util.HashSet;
import java.util.Set;

public class SudokuValidator {

    public boolean canPlace(Board board, int row, int col, int value) {
        if (value < 1 || value > 9) {
            return false;
        }

        for (int c = 0; c < Board.SIZE; c++) {
            if (c != col && board.getValue(row, c) == value) {
                return false;
            }
        }

        for (int r = 0; r < Board.SIZE; r++) {
            if (r != row && board.getValue(r, col) == value) {
                return false;
            }
        }

        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int r = startRow; r < startRow + 3; r++) {
            for (int c = startCol; c < startCol + 3; c++) {
                if ((r != row || c != col) && board.getValue(r, c) == value) {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean isValid(Board board) {
        for (int i = 0; i < Board.SIZE; i++) {
            if (hasDuplicates(board.getRowValues(i)) || hasDuplicates(board.getColumnValues(i))) {
                return false;
            }
        }

        for (int row = 0; row < Board.SIZE; row += 3) {
            for (int col = 0; col < Board.SIZE; col += 3) {
                if (hasDuplicates(board.getBoxValues(row, col))) {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean isSolved(Board board) {
        return board.isComplete() && isValid(board);
    }

    private boolean hasDuplicates(int[] values) {
        Set<Integer> seen = new HashSet<>();
        for (int value : values) {
            if (value == 0) {
                continue;
            }
            if (!seen.add(value)) {
                return true;
            }
        }
        return false;
    }
}
