package com.victorlima.sudoku.service;

import com.victorlima.sudoku.model.Board;

public class SudokuSolver {
    private final SudokuValidator validator;

    public SudokuSolver(SudokuValidator validator) {
        this.validator = validator;
    }

    public boolean solve(Board board) {
        for (int row = 0; row < Board.SIZE; row++) {
            for (int col = 0; col < Board.SIZE; col++) {
                if (board.getValue(row, col) == 0) {
                    for (int value = 1; value <= 9; value++) {
                        if (validator.canPlace(board, row, col, value)) {
                            board.setValue(row, col, value);
                            if (solve(board)) {
                                return true;
                            }
                            board.setValue(row, col, 0);
                        }
                    }
                    return false;
                }
            }
        }
        return validator.isSolved(board);
    }
}
