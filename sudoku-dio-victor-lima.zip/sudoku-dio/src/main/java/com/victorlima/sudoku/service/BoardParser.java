package com.victorlima.sudoku.service;

import com.victorlima.sudoku.model.Board;

public final class BoardParser {

    private BoardParser() {
    }

    public static Board parse(String[] args) {
        Board board = new Board();

        for (String arg : args) {
            if (arg == null || arg.isBlank()) {
                continue;
            }

            String[] positionAndData = arg.trim().split(";");
            if (positionAndData.length != 2) {
                throw new IllegalArgumentException("Argumento inválido: " + arg);
            }

            String[] position = positionAndData[0].split(",");
            String[] data = positionAndData[1].split(",");

            if (position.length != 2 || data.length != 2) {
                throw new IllegalArgumentException("Argumento inválido: " + arg);
            }

            int col = Integer.parseInt(position[0].trim());
            int row = Integer.parseInt(position[1].trim());
            int value = Integer.parseInt(data[0].trim());
            boolean fixed = Boolean.parseBoolean(data[1].trim());

            board.setInitialCell(row, col, value, fixed);
        }

        return board;
    }
}
