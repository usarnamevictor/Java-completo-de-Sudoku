package com.victorlima.sudoku.model;

import java.util.Arrays;

public class Board {
    public static final int SIZE = 9;
    private final Cell[][] cells;

    public Board() {
        this.cells = new Cell[SIZE][SIZE];
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                cells[row][col] = new Cell(row, col, 0, false);
            }
        }
    }

    public Cell getCell(int row, int col) {
        validatePosition(row, col);
        return cells[row][col];
    }

    public void setInitialCell(int row, int col, int value, boolean fixed) {
        validatePosition(row, col);
        validateValue(value);
        cells[row][col] = new Cell(row, col, value, fixed);
    }

    public int getValue(int row, int col) {
        return getCell(row, col).getValue();
    }

    public boolean isFixed(int row, int col) {
        return getCell(row, col).isFixed();
    }

    public void setValue(int row, int col, int value) {
        validatePosition(row, col);
        validateValue(value);
        if (cells[row][col].isFixed()) {
            throw new IllegalStateException("Não é possível alterar uma célula fixa.");
        }
        cells[row][col].setValue(value);
    }

    public boolean isComplete() {
        for (Cell[] row : cells) {
            for (Cell cell : row) {
                if (cell.isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }

    public int[] getRowValues(int row) {
        validateIndex(row);
        int[] values = new int[SIZE];
        for (int col = 0; col < SIZE; col++) {
            values[col] = cells[row][col].getValue();
        }
        return values;
    }

    public int[] getColumnValues(int col) {
        validateIndex(col);
        int[] values = new int[SIZE];
        for (int row = 0; row < SIZE; row++) {
            values[row] = cells[row][col].getValue();
        }
        return values;
    }

    public int[] getBoxValues(int row, int col) {
        validatePosition(row, col);
        int[] values = new int[SIZE];
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        int index = 0;

        for (int r = startRow; r < startRow + 3; r++) {
            for (int c = startCol; c < startCol + 3; c++) {
                values[index++] = cells[r][c].getValue();
            }
        }
        return values;
    }

    public Board copy() {
        Board copy = new Board();
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                Cell cell = cells[row][col];
                copy.setInitialCell(row, col, cell.getValue(), cell.isFixed());
            }
        }
        return copy;
    }

    private void validatePosition(int row, int col) {
        validateIndex(row);
        validateIndex(col);
    }

    private void validateIndex(int index) {
        if (index < 0 || index >= SIZE) {
            throw new IllegalArgumentException("Linha e coluna devem estar entre 0 e 8.");
        }
    }

    private void validateValue(int value) {
        if (value < 0 || value > 9) {
            throw new IllegalArgumentException("O valor deve estar entre 0 e 9.");
        }
    }

    @Override
    public String toString() {
        return Arrays.deepToString(cells);
    }
}
