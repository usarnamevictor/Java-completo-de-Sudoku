package com.victorlima.sudoku;

import com.victorlima.sudoku.model.Board;
import com.victorlima.sudoku.service.BoardParser;
import com.victorlima.sudoku.service.SudokuGame;
import com.victorlima.sudoku.util.BoardPrinter;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        if (args.length == 0) {
            printUsage();
            return;
        }

        Board board = BoardParser.parse(args);
        SudokuGame game = new SudokuGame(board);
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Sudoku DIO - Versão Terminal ===");
        System.out.println("Digite um comando: set, clear, validate, solve, show ou exit");

        while (true) {
            BoardPrinter.print(game.getBoard());

            if (game.isSolved()) {
                System.out.println("Parabéns! Você concluiu o Sudoku.");
                break;
            }

            System.out.print("> ");
            String command = scanner.next().trim().toLowerCase();

            try {
                switch (command) {
                    case "set" -> {
                        System.out.print("linha coluna valor: ");
                        int row = scanner.nextInt();
                        int col = scanner.nextInt();
                        int value = scanner.nextInt();
                        boolean success = game.placeNumber(row, col, value);
                        System.out.println(success ? "Valor inserido com sucesso." : "Movimento inválido para as regras do Sudoku.");
                    }
                    case "clear" -> {
                        System.out.print("linha coluna: ");
                        int row = scanner.nextInt();
                        int col = scanner.nextInt();
                        game.placeNumber(row, col, 0);
                        System.out.println("Posição limpa.");
                    }
                    case "validate" -> System.out.println(game.isValid() ? "Tabuleiro válido até o momento." : "Tabuleiro inválido.");
                    case "solve" -> {
                        System.out.println("Solução sugerida:");
                        BoardPrinter.print(game.solveCopy());
                    }
                    case "show" -> BoardPrinter.print(game.getBoard());
                    case "exit" -> {
                        System.out.println("Encerrando o jogo.");
                        return;
                    }
                    default -> System.out.println("Comando inválido. Use: set, clear, validate, solve, show ou exit.");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
                scanner.nextLine();
            }
        }
    }

    private static void printUsage() {
        System.out.println("Uso: java -jar sudoku-dio.jar \"0,0;4,false\" \"1,0;7,false\" ...");
        System.out.println("Formato de cada argumento: coluna,linha;valor,fixo");
        System.out.println("Exemplo: 0,0;4,false");
    }
}
