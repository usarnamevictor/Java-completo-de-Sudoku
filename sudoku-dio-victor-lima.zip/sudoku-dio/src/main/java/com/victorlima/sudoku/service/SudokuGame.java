package com.victorlima.sudoku.service;

import com.victorlima.sudoku.model.Board;

public class SudokuGame {
    private final Board board;
    private final SudokuValidator validator;
    private final SudokuSolver solver;

    public SudokuGame(Board board) {
        this.board = board;
        this.validator = new SudokuValidator();
        this.solver = new SudokuSolver(validator);
    }

    public Board getBoard() {
        return board;
    }

    public boolean placeNumber(int row, int col, int value) {
        if (board.isFixed(row, col)) {
            throw new IllegalStateException("A posição informada é fixa.");
        }

        if (value == 0) {
            board.setValue(row, col, 0);
            return true;
        }

        if (!validator.canPlace(board, row, col, value)) {
            return false;
        }

        board.setValue(row, col, value);
        return true;
    }

    public boolean isSolved() {
        return validator.isSolved(board);
    }

    public boolean isValid() {
        return validator.isValid(board);
    }

    public Board solveCopy() {
        Board copy = board.copy();
        if (!solver.solve(copy)) {
            throw new IllegalStateException("O tabuleiro atual não possui solução.");
        }
        return copy;
    }
}
