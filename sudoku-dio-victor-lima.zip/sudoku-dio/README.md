# Sudoku DIO em Java

Projeto prático de Sudoku em Java desenvolvido para o desafio da DIO, inspirado no repositório de referência disponibilizado pela plataforma. A aplicação roda no terminal, interpreta o tabuleiro via argumentos de execução e oferece comandos para jogar, validar e resolver o Sudoku. A referência original da DIO aponta para um repositório Java com branch principal para jogo no terminal e uma branch `ui` para interface gráfica. citeturn880922view0turn880922view1

## Funcionalidades

- Leitura do tabuleiro inicial por argumentos no formato exigido pelo desafio
- Exibição formatada do tabuleiro no terminal
- Inserção e remoção de números
- Validação de linhas, colunas e subgrades 3x3
- Resolução automática por backtracking
- Testes unitários com JUnit 5
- Estrutura pronta para portfólio no GitHub

## Estrutura do projeto

```text
sudoku-dio/
├── docs/
├── src/
│   ├── main/java/com/victorlima/sudoku/
│   │   ├── model/
│   │   ├── service/
│   │   ├── util/
│   │   └── Main.java
│   └── test/java/com/victorlima/sudoku/service/
├── pom.xml
└── README.md
```

## Requisitos

- Java 17+
- Maven 3.9+

## Como executar

### 1. Compilar

```bash
mvn clean package
```

### 2. Rodar o jogo

```bash
java -jar target/sudoku-dio-1.0.0.jar "0,0;4,false" "1,0;7,false" "2,0;9,true"
```

> O formato de cada argumento é: `coluna,linha;valor,fixo`

## Comandos do jogo

- `set` → define um valor em uma posição
- `clear` → limpa uma posição não fixa
- `validate` → verifica se o tabuleiro continua válido
- `solve` → mostra a solução calculada
- `show` → exibe o tabuleiro novamente
- `exit` → encerra a aplicação

## Argumentos de exemplo

Você pode usar os argumentos abaixo para testar exatamente o cenário informado no desafio:

```text
0,0;4,false 1,0;7,false 2,0;9,true 3,0;5,false 4,0;8,true 5,0;6,true 6,0;2,true 7,0;3,false 8,0;1,false 0,1;1,false 1,1;3,true 2,1;5,false 3,1;4,false 4,1;7,true 5,1;2,false 6,1;8,false 7,1;9,true 8,1;6,true 0,2;2,false 1,2;6,true 2,2;8,false 3,2;9,false 4,2;1,true 5,2;3,false 6,2;7,false 7,2;4,false 8,2;5,true 0,3;5,true 1,3;1,false 2,3;3,true 3,3;7,false 4,3;6,false 5,3;4,false 6,3;9,false 7,3;8,true 8,3;2,false 0,4;8,false 1,4;9,true 2,4;7,false 3,4;1,true 4,4;2,true 5,4;5,true 6,4;3,false 7,4;6,true 8,4;4,false 0,5;6,false 1,5;4,true 2,5;2,false 3,5;3,false 4,5;9,false 5,5;8,false 6,5;1,true 7,5;5,false 8,5;7,true 0,6;7,true 1,6;5,false 2,6;4,false 3,6;2,false 4,6;3,true 5,6;9,false 6,6;6,false 7,6;1,true 8,6;8,false 0,7;9,true 1,7;8,true 2,7;1,false 3,7;6,false 4,7;4,true 5,7;7,false 6,7;5,false 7,7;2,true 8,7;3,false 0,8;3,false 1,8;2,false 2,8;6,true 3,8;8,true 4,8;5,true 5,8;1,false 6,8;4,true 7,8;7,false 8,8;9,false
```

## Melhorias implementadas

- Organização em camadas simples (`model`, `service`, `util`)
- Solver automático para demonstrar lógica adicional
- Testes automatizados
- README pronto para recrutadores e avaliadores

## Links úteis

- Repositório base da DIO: GitHub da Digital Innovation One. citeturn880922view0
- Branch com interface gráfica mencionada na descrição do desafio. citeturn880922view1
- Draw.io para diagramas: app.diagrams.net

## Sugestões para evoluir

- Criar interface gráfica com JavaFX ou Swing
- Adicionar níveis de dificuldade
- Gerar tabuleiros aleatórios
- Exportar partida em arquivo
- Publicar pipeline CI no GitHub Actions
